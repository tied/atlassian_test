package com.example.plugins.tutorial.jira.customfields;


import net.java.ao.Entity;

public interface MyEntity extends Entity{
	String getName();
	void setName(String name);
}
